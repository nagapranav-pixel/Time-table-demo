# IIIT Sri City UG1 Timetable

A static Monsoon 2026 UG1 timetable with roll-number lookup, section-aware classes, holidays, and special timetable days.

## GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`, `students.json`, and `.nojekyll` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Open the published Pages URL after GitHub finishes deploying.

GitHub Pages publishes static HTML/CSS/JavaScript sites directly from a repository.

## Important privacy note

The included `students.json` contains student roll-number/name/section mappings. A public static site makes that data downloadable by anyone. For a real college-wide deployment, move the mapping behind a backend/API or otherwise obtain the necessary permission before publishing it publicly.
